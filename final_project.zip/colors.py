class Colors:
    WHITE = "#ffffff"
    RED = "#ff0000"
    GREEN = "#00ff00"
